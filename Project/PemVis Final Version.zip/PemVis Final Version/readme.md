Final Version of 3 Dimensional Face Recognition

Directory
/arduino/arduino.ino    -> Source Code for Arduino
/csv                    -> database of photos converted into csv format
/dataset                -> database of existing user

Source Code
faceRecV3a.py           -> Source Code With Arduino Connection
faceRecV4a.py           -> Source Code Without Arduino Connection

Source of the Code
https://github.com/1adrianb/face-alignment
https://github.com/kevinam99/capturing-images-from-webcam-using-opencv-python/blob/master/webcam-capture-v1.01.py